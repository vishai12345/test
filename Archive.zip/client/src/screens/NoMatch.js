import React, { Component } from 'react';

export default class NoMatch extends Component {
  render() {
    return (
        <div>
            <h1>No Match Found</h1>
        </div>
    );
  }
}
